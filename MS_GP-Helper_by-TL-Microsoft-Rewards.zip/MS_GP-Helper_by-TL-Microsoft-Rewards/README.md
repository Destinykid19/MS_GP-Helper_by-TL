# MS_GP-Helper_by-TL
Automated random searches with GUI to help you with your Microsoft Rewards daily searches.
Download the folder
Unpack it
Start main.py
enter the data and click search

NOTE: Your Windows defender or Anti-Viruses might flag this programm. You'll need to whitelist main.py. It's open source so you can and should check the code before starting it.

Have fun :)
